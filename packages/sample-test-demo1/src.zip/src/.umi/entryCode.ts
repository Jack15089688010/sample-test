
    window.g_umi = {
      version: '3.1.1',
    };
  

    (() => {
      try {
        const ua = window.navigator.userAgent;
        const isIE = ua.indexOf('MSIE ') > -1 || ua.indexOf('Trident/') > -1;
        if (isIE) return;

        // Umi UI Bubble
        require('D:/Hand_Work/sample-test/node_modules/hzero-cli-preset-ui/lib/bubble').default({
          port: 3000,
          path: 'D:/Hand_Work/sample-test/packages/sample-test-demo1',
          currentProject: '',
          isBigfish: undefined,
        });
      } catch (e) {
        console.warn('Umi UI render error:', e);
      }
    })();
  