import { IConfig } from 'umi'; // ref: https://umijs.org/config/
import parentUmiConfig from '../../.umirc';

const config: IConfig = parentUmiConfig;

export default config;
