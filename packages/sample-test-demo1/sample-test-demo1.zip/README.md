# `demo1`

> TODO: description

## Usage

```
const sample-testdemo1 = require('sample-test-demo1');

// TODO: DEMONSTRATE API
```

```
SASS
[object Object]

```
