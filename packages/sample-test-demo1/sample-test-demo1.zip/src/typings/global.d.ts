// import '../../../../src/typings/global.d.ts';
// eslint-disable-next-line
/// <reference path="../../../../src/typings/global.d.ts" />
