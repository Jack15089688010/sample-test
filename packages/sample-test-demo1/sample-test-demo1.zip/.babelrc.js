module.exports = {
  extends: '../../.babelrc',
};
